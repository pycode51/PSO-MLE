# -*- coding:utf-8 -*- 
# time  :  2021/5/10 15:12

from sko.PSO import PSO
import numpy as np
from scipy.special import gamma
import scipy.stats as sts
from scipy.optimize import curve_fit

############## Hydrological series #################

xp = np.array([526.0, 575.3, 507.9, 611.6, 538.9, 627.6, 503.0, 677.6, 527.9,
               463.8, 685.8, 520.0, 547.7, 783.6, 500.1, 617.5, 635.2, 643.1,
               439.4, 606.5, 448.9, 450.4, 584.7, 534.8, 668.3, 544.6, 457.7,
               576.7, 481.2, 528.5, 617.4, 425.3, 715.3, 660.6, 559.1, 401.9,
               474.7, 643.8, 525.4, 659.9, 439.5, 567.9, 490.7, 478.4, 386.1,
               554.5, 355.3, 565.7, 489.0, 472.2, 486.9, 484.1, 760.0, 463.1,
               521.9, 506.3, 535.8, 445.8, 459.6, 554.9, 598.1]
              )


############# P-III MaxiuMaximum likelihood estimation #################
class P3_MLE(object):
    """
    introduction:
        This algorithm is used to solve the maximum likelihood estimation of P-III
        distribution based on particle swarm optimization algorithm.

    Parameters:
    --------------------
    xp: hydrological series
    pso: PSO-MLE model
    w_max: Maximum inertia weight
    w_min: Minimum inertia weight
    b: damping Factor
    c1,c2: acceleration factor
    pop: number of population
    max_iter: maximum number of iterations

    functions:
    --------------------
    ML : Likelihood function
    cal_fitness : Fitness function
    SE: Moment estimation calculation
    FIT: Optimized line fit method
    Python_MLE: the maximum likelihood estimation based on python
    """

    def __init__(self, xp, w_max=0.9, w_min=0.4, b=0.5, c1=1.5, c2=1.5, pop=100, max_iter=100):
        self.xp = xp
        self.w_max = w_max
        self.w_min = w_min
        self.pop = pop
        self.max_iter = max_iter
        self.b = b
        self.c1 = c1
        self.c2 = c2
        a_S, b_S, c_S = self.SE()[:3]
        self.pso = PSO(func=self.ML, n_dim=3, pop=self.pop, max_iter=self.max_iter,
                       lb=[0.1 * a_S, 0.1 * b_S, c_S - np.abs(c_S)], ub=[10 * a_S, 10 * b_S, np.min(self.xp) - 0.01],
                       w_start=self.w_max, w_end=self.w_min, c1=self.c1, c2=self.c2, b=self.b)

    def ML(self, x):
        alpha, beta, x0 = x
        n = len(self.xp)
        c1 = -n * alpha * np.log(beta)
        c2 = - n * np.log(gamma(alpha))
        c3 = (alpha - 1) * np.sum(np.log(self.xp - x0))
        c4 = - 1 / (beta) * np.sum(self.xp - x0)
        fitness = -(c1 + c2 + c3 + c4)
        return fitness

    def cal_fitness(self, alpha, beta, x0):
        n = len(self.xp)
        c1 = -n * alpha * np.log(beta)
        c2 = - n * np.log(gamma(alpha))
        c3 = (alpha - 1) * np.sum(np.log(self.xp - x0))
        c4 = - 1 / (beta) * np.sum(self.xp - x0)
        lnL = -(c1 + c2 + c3 + c4)
        return lnL

    def SE(self):
        Ex = np.mean(self.xp)
        k = self.xp / Ex
        cv = np.sqrt(np.sum((k - 1) ** 2) / (len(self.xp) - 1))
        cs = np.sum((k - 1) ** 3) / ((len(self.xp) - 3) * cv ** 3)
        alpha = 4 / (cs ** 2)
        beta = 2 / (cv * cs * Ex)
        a0 = Ex * (1 - 2 * cv / cs)
        a_s = alpha
        b_s = 1 / beta
        c_s = a0
        SElnL = self.cal_fitness(a_s, b_s, c_s)
        return a_s, b_s, c_s, SElnL

    def FIT(self):
        def optimize_func(x, alpha, beta, a0):
            fitfunc = sts.gamma(a=alpha, scale=1 / beta)
            return fitfunc.ppf(x) + a0

        hydroseq = self.xp.copy()
        hydroseq.sort()
        hydroseq = np.flip(hydroseq)
        ls = np.arange(1, len(hydroseq) + 1)
        p = 1 - ls / (len(hydroseq) + 1)
        popt, pcov = curve_fit(optimize_func, p, hydroseq)
        a_fit, b_fit, c_fit = popt
        FITLnL = self.cal_fitness(a_fit, 1 / b_fit, c_fit)
        return a_fit, 1 / b_fit, c_fit, FITLnL

    def Python_MLE(self):
        a, c, b = sts.gamma.fit(self.xp)
        PYlnL = self.cal_fitness(a, b, c)
        return a, b, c, PYlnL

    def run(self, cir_num=200, visual=False, N=20, accuracy=None):
        c = 0
        for num in range(cir_num):
            self.pso.run(precision=None, cir_time=num)
            if accuracy is not None:
                self.tor_iter = np.amax(self.pso.pbest_y) - np.amin(self.pso.pbest_y)
                if self.tor_iter < accuracy:
                    c = c + 1
                    if c > N:
                        break
                else:
                    c = 0
            if visual:
                try:
                    print('best_x is ', self.pso.gbest_x[0], self.pso.gbest_x[1], self.pso.gbest_x[2],
                          'best_y is', self.pso.gbest_y[0])
                except:
                    pass
            else:
                pass
        return self.pso.gbest_x[0], self.pso.gbest_x[1], self.pso.gbest_x[2], self.pso.gbest_y[0]


if __name__ == "__main__":
    model = P3_MLE(xp=xp, pop=100)
    print(f"FIT：alpha={model.FIT()[0]}|beta ={model.FIT()[1]}|a0={model.FIT()[2]}|-lnL={model.FIT()[3]}")
    print(f"MOM：alpha={model.SE()[0]}|beta ={model.SE()[1]}|a0={model.SE()[2]}|-lnL={model.SE()[3]}")
    print(f"Python-MLE：alpha={model.Python_MLE()[0]}|beta={model.Python_MLE()[1]}|a0={model.Python_MLE()[2]}|-lnL={model.Python_MLE()[3]}")
    pso_mle = model.run(cir_num=200, visual=True, N=10, accuracy=1e-8)
    print(f"PSO-MLE:alpha={pso_mle[0]}|beta={pso_mle[1]}|a0={pso_mle[2]}|-lnL={pso_mle[3]}")
    print("cycle-running-times:", model.pso.cir_time)
